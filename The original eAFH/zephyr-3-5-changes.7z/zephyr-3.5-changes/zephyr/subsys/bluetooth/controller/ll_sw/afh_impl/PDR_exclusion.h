/*
 * Copyright (c) 2020 Kiel University
 *
 * SPDX-License-Identifier: Apache-2.0
 */

#if defined(CONFIG_BT_AFH_PDR_EXCLUSION)
    #define WINDOW_SIZE 20
	#define MIN_SCORE 0.95f
	#define MIN_NUM_CHANNELS 10
#endif
